#!/bin/bash
if [[ -z "$1" ]]; then
  echo "Please enter version number like this 0.1.8";
#  exit 1;
fi

get_number_from_file() {
	cat "$1" | head -1 | grep -Ex "[0-9]+";
}

set -e;
CURRENT_DIRECTORY="$(dirname "$(readlink -f "$BASH_SOURCE")")";
TARGET_DIRECTORY="${CURRENT_DIRECTORY}/binancetradingbot";
TEMP_CHANGELOG="${CURRENT_DIRECTORY}/debian/tmmmp";
CHANGELOG="${CURRENT_DIRECTORY}/debian/changelog";
VERSION_MAJOR="$(get_number_from_file "${CURRENT_DIRECTORY}/debian/version/1_major")";
VERSION_MINOR="$(get_number_from_file "${CURRENT_DIRECTORY}/debian/version/2_minor")";
VERSION_BUILD="$(get_number_from_file "${CURRENT_DIRECTORY}/debian/version/3_build")";
VERSION_BUILD="$(( ${VERSION_BUILD} + 1))";
cp -v "${CHANGELOG}" "${TEMP_CHANGELOG}";
echo "collector (${VERSION_MAJOR}.${VERSION_MINOR}.${VERSION_BUILD}) unstable; urgency=medium" > "${CHANGELOG}";
echo "" >> "${CHANGELOG}";
cd "${TARGET_DIRECTORY}";
git log | grep -v -e Author -e commit -e Date | grep -v '^$' | head -10 | sed -e 's/    //' | sed -e 's/^/  * /' >> "${CHANGELOG}";
AUTHOR="$(git log | grep -m 1 Author)";
cd -;
echo "" >> "${CHANGELOG}";
echo " --${AUTHOR#Author\:}  $(date -R)" >> "${CHANGELOG}";
echo "" >> "${CHANGELOG}";
cat "${TEMP_CHANGELOG}" >> "${CHANGELOG}";
rm -v "${TEMP_CHANGELOG}";

### Baut ohne die Signierung
dpkg-buildpackage -uc -us
echo "${VERSION_BUILD}" > "${CURRENT_DIRECTORY}/debian/version/3_build"; 
